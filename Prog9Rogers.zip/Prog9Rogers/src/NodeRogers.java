/**
 * 
 * @author Caleb Rogers <br>
 *
 * This is the class definition for NodeRogers
 */
public class NodeRogers 
{
/**
 * Instance variable for myData
 */
private ItemRogers myData;
/**
 * Instance variable for myNext
 */
private NodeRogers myNext;
	
	/**
	 * The default constructor for NodeRogers
	 */
	public NodeRogers()
		{
		myData = null;
		myNext = null;
		} // NodeRogers
	
	/**
	 * This constructor assigns incoming variables for NodeRogers
	 * @param newData	The new data of an item
	 */
	public NodeRogers(ItemRogers newData)
		{
		myData = newData;
		myNext = null;
		} // NodeRogers
	
	/**
	 * The getter for myData
	 * @return	Returns the data of an item
	 */
	public ItemRogers getData()
		{
		return myData;
		} // getData
	
	/**
	 * The setter for myData
	 * @param newData	The incoming data for an item
	 */
	public void setData(ItemRogers newData)
		{
		myData = newData;
		} // setData
	
	/**
	 * The getter for myData
	 * @return	Returns the next
	 */
	public NodeRogers getNext()
		{
		return myNext;
		} // getNext
	/**
	 * The incoming next
	 * @param newNext
	 */
	public void setNext(NodeRogers newNext)
		{
		myNext = newNext;
		} // setNext
} // NodeRogers
