/**
 * 
 * @author Caleb Rogers <br>
 *
 * This is the class definition for KeyedListRogers
 */
public class KeyedListRogers
{
/**
 * Instance variable for the head of the array
 */
private NodeRogers myHead;
	
	/**
	 * The default constructor for KeyedListRogers
	 */
	public KeyedListRogers()
		{
		myHead = null;
		} // KeyedListRogers
	
	/**
	 * The getter for the head of the array
	 * @return
	 */
	public NodeRogers getHead()
		{
		return myHead;
		} // getHead
	
	/**
	 * The setter for the head of the array
	 * @param newHead
	 */
	public void setHead(NodeRogers newHead)
		{
		myHead = newHead;
		} // setHead
	
	/**
	 * This method clears the shopping list
	 */
	public void clear()
		{
		setHead(null);
		} // clear
	
	/**
	 * This method adds a new item to the shopping list
	 * @param newItem	item to be added
	 * @return added	whether item was added or not
	 */
	public boolean add(ItemRogers newItem)
		{
		NodeRogers curr = myHead;
		NodeRogers prev = null;
		NodeRogers addition = null;
		boolean location = false;
		boolean duplicate = false;
		boolean added = false;
		
		while((curr != null) && (!location))
			{
			if(curr.getData().getName().compareToIgnoreCase(newItem.getName()) == 0)
				duplicate = true;
			
			if(curr.getData().getName().compareToIgnoreCase(newItem.getName()) > 0)
				location = true;
			else
				{
				prev = curr;
				curr = curr.getNext();
				} // else
			} // while
		
		
		if(!duplicate)
			{
			addition = new NodeRogers(newItem);
			addition.setNext(curr);
		
			if(prev == null)
				{
				addition.setNext(myHead);
				myHead = addition;
				} // if
			else
				{
				addition.setNext(curr);
				prev.setNext(addition);
				} // else
			
			added = true;
			} // if
			
		return added;	
		} // add
	
	/**
	 * removes an item from the shopping list
	 * @param delItem	item to be removed
	 * @return found	whether item was found and deleted or not
	 */
	public boolean remove(String delItem)
		{
		NodeRogers curr = myHead;
		NodeRogers prev = null;
		boolean found = false;
		
		while((curr != null) && (!found))
			{
			if(curr.getData().getName().compareToIgnoreCase(delItem) == 0)
				found = true;
			else 
				{
				prev = curr;
				curr = curr.getNext();
				} // else
			
			if(found)
				{
				if(prev == null)
					myHead = curr.getNext();
				else if(curr != null)
					prev.setNext(curr.getNext());
				} // if
			} // while
		
		return found;
		} // remove
	
	/**
	 * This method returns a searched item
	 * @param findItem	name of item being searched
	 * @return foundItem	item that was searched
	 */
	public ItemRogers retrieve(String findItem)
		{
		ItemRogers foundItem = null;
		boolean found = false;
		NodeRogers curr = myHead;
		
		while((curr != null) && (!found))
			{
			if(curr.getData().getName().compareToIgnoreCase(findItem) == 0)
				{
				foundItem = curr.getData();
				found = true;
				} // if
			else
				{
				curr = curr.getNext();
				} // else
			} // while
		return foundItem;
		} // retrieve
	
	/**
	 * This method returns whether the shopping list is empty or not
	 * @return	whether shopping list is empty or not
	 */
	public boolean isEmpty()
		{
		return(myHead == null);
		} // isEmpty
	
	/**
	 * This method returns whether the shopping list is full or not
	 * @return always false because the list will never be full
	 */
	public boolean isFull()
		{
		return false;
		} // isFull
	
	/**
	 * This method prints the items in the shopping list
	 */
	public void print()
		{
		NodeRogers curr = myHead;
		int i = 0;
		while(curr != null)
			{
			System.out.println("~~~~~ " + (i+1) + " ~~~~~");
			System.out.println(curr.getData().toString());
			System.out.println();
			curr = curr.getNext();
			i++;
			} // while
		} // print
	
	/**
	 * This method counts how many items are in the shopping list
	 * @return	count	number of items in shopping list
	 */
	public int getCount()
		{
		int count = 0;
		NodeRogers curr = myHead;
		while(curr != null)
			{
			count += curr.getData().getQuantity();
			curr = curr.getNext();
			} // while
		return count;
		} // getCount
	
	/**
	 * This method calculates the total price of the shopping list
	 * @return total	total cost of shopping list
	 */
	public double calcTotal()
		{
		double total = 0.0;
		NodeRogers curr = myHead;
		while(curr != null)
			{
			total += (curr.getData().getQuantity()) * (curr.getData().getPrice());
			curr = curr.getNext();
			} // while
		return total;
		} // calcTotal
} // KeyedListRogers