// Caleb Rogers
// Prog 4
// Due Date and Time: 2/24/20 before 9:00 a.m.
//
// Purpose: This program presents options to either calculate
// golf scores, determine whether there are more evens or odds
// in an array, or determine how many times the minimum value
// of an array appears in the array.
//
// Input: Menu choice; Par values and Number of Strokes per Hole
// for option 1; up to ten integers and 0 to continue for
// option 2; or Inputs up to 8 integers and a negative integer
// to continue for option 3
//
// Output: Golf scores for option 1; or whether there's more evens
// or odds for option 2; or the array, the minimum value, and the
// appearances of the minimum value for option 3
//
// Certification of Authenticity:
// I certify that this lab is entirely my own work.
//
import java.util.Scanner;

public class ArraysRogers 
{
	static Scanner keyboard = new Scanner(System.in);
	
	public static void main(String[] args) 
	{	

	// Initialize
	int menuChoice = 0;
	
	// Greeting
	System.out.println("Welcome, this program will present different options to explore lists!");
	System.out.println();
	
	do 
		{
		// Menu
		System.out.println("{Select a choice from the following menu}");
		System.out.println("1) Let's Go Golfing!");
		System.out.println("2) More Evens or More Odds?");
		System.out.println("3) How Many Mins?");
		System.out.println("0) Quit Program");
		
		// Menu Choice
		System.out.print("Enter your menu choice: ");
		menuChoice = keyboard.nextInt();
			
		switch (menuChoice)
			{
			case 1: letsGolf();
					break;
				
			case 2: evensOrOdds();
					break;
				
			case 3: manyMins();
					break;
					
			case 0: System.out.println("\nThanks for participating in Caleb's experimental program!");
					System.out.println("Goodbye");
					keyboard.close();
					break;
					
			default: System.out.println("\nInvalid input! Enter an option from the menu ");
					System.out.println();
					break;
			} // switch
		
		} // do
	while (menuChoice != 0);
	
	} // main
	
	// Method: letsGolf
	// Description: Inputs Par values and number of strokes per hole
	// and calls helper method, golfScores, to calculate and
	// output the golf scores
	public static void letsGolf()
		{
		// Initialization
		int[] parValues = new int[9];
		int[] numStrokes = new int[9];
		int i = 0;
		
		// Greeting
		System.out.println("\nWelcome to Let's Go Golfing!");
		System.out.println("Enter the following information to calculate your golf scores!");
		System.out.println("Your input should be exactly 9 integers for each");
		
		// Input Par values
		System.out.println("\n<Input your values representing Par values for each hole>");
		for (i = 0; i < 9; i++)
			{
			System.out.print("Enter value " + (i+1) + ": ");
			parValues[i] = keyboard.nextInt();
			} // for
		
		// Input Number of Strokes per Hole
		System.out.println("\n<Input your values representing the number of strokes for each hole>");
		for (i = 0; i < 9; i++)
			{
			System.out.print("Enter value " + (i+1) + ": ");
			numStrokes[i] = keyboard.nextInt();
			} // for
		
		// Calculate and Output Scores
		golfScores(parValues, numStrokes);
		
		} // letsGolf
	
	// Method: evensOrOdds
	// Description: Inputs up to ten integers and 0 to continue,
	// then calls helper method, moreEvensOrOdds, to calculate
	// and output whether there's more evens or odds
	public static void evensOrOdds()
		{
		//Initialization
		int[] nums = new int[10];
		int value = 0;
		int count = 0;
		
		// Greeting
		System.out.println("\nWelcome to More Evens or More Odds?");
		System.out.println("Enter the following information to calculate whether there are evens or more odds!");
		System.out.println("Your input should be up to 10 integers and '0' to continue (if necessary)");
		
		// Input Numbers
		System.out.println("\n<Input your values>");
		do
			{
			System.out.print("Enter value " + (count+1) + ": ");
			value = keyboard.nextInt();
			nums[count] = value;
			count++;
			if (value == 0)
				count -= 1;
			} // do
		while ((count < 10) && (value != 0));
		
		// Calculate and Output Whether There's More Evens or Odds
		moreEvensOrOdds(nums, count);
		
		} // evensOrOdds
	
	// Method: manyMins
	// Description: Inputs up to 8 integers and a negative
	// integer to continue, then calls helper method, findAndCountMins,
	// to calculate and output the array, the minimum value, and the
	// appearances of the minimum value
	public static void manyMins()
		{
		// Initialization
		int[] nums = new int[8];
		int value = 0;
		int count = 0;
		
		// Greeting
		System.out.println("\nWelcome to How Many Mins?");
		System.out.println("Enter the following information to calculate how many times the minimum value appears!");
		System.out.println("Your input should be up to 8 integers and a non-positive integer to continue (if necessary)");
		
		// Input Numbers
		System.out.println("\n<Input your values>");
		do
			{
			System.out.print("Enter value " + (count+1) + ": ");
			value = keyboard.nextInt();
			nums[count] = value;
			count++;
			if (value <= 0)
				count -= 1;
			} // do
		while ((count < 8) && (value > 0));
		
		// Calculate and Output the Array, the Min, and Count of Min
		findAndCountMins(nums, count);
		
		} // manyMins
	
	// Helper Method: golfScores
	// Description: takes in parameters par and strokes,
	// then calculates and outputs the golf scores
	public static void golfScores(int[] par, int[] strokes)
		{
		// Initialization
		int i = 0;
		int eagles = 0;
		int birdies = 0;
		int pars = 0;
		int bogeys = 0;
		int doubleBogeys = 0;
		int other = 0;
		
		// Calculate Scores
		for (i = 0; i < 9; i++)
			{
			if ((par[i] - 2) == strokes[i])
				eagles++;
			else if ((par[i] - 1) == strokes[i])
				birdies++;
			else if (par[i] == strokes[i])
				pars++;
			else if ((par[i] + 1) == strokes[i])
				bogeys++;
			else if ((par[i] + 2) == strokes[i])
				doubleBogeys++;
			else 
				other++;
			} // for
		
		// Output Scores
		System.out.println("\n~~Golf Scores~~");
		System.out.println("Eagles: " + eagles);
		System.out.println("Birdies: " + birdies);
		System.out.println("Pars: " + pars);
		System.out.println("Bogeys: " + bogeys);
		System.out.println("Double Bogeys: " + doubleBogeys);
		System.out.println("Other: " + other);
		System.out.println("Thanks for playing Let's Go Golfing!");
		System.out.println();
		
		} // golfScores
	
	// Helper Method: moreEvensOrOdds
	// Description: takes in values and size, then calculates
	// and outputs whether there are more evens or odds
	public static void moreEvensOrOdds(int[] values, int size)
		{
		// Initialization
		int i = 0;
		int evens = 0;
		int odds = 0;
		
		// Calculate Number of Evens and Odds
		for (i = 0; i < size; i++)
			{
			if ((values[i] % 2) == 0)
				evens++;
			else
				odds++;
			} // for
		
		// Output Whether More Evens or Odds
		if (evens > odds)
			{
			System.out.println("\nThere are more evens than odds");
			System.out.println("The list of evens are:");
			for (i = 0; i < size; i++)
				if ((values[i] % 2) == 0)
					System.out.print(values[i] + " ");
			System.out.println();
			} // if
		
		else if(evens < odds)
			{
			System.out.println("\nTheres are more odds than evens");
			System.out.println("The list of odds are:");
			for (i = 0; i < size; i++)
				if ((values[i] % 2) != 0)
					System.out.print(values[i] + " ");
			System.out.println();
			} // if
		
		else
			{
			System.out.println("\nThe number of evens are equal to the number of odds");
			System.out.println("The entire list is:");
			for (i = 0; i < size; i++)
				System.out.print(values[i] + " ");
			System.out.println();
			} // if
		
		// Output Helper Method Closing
		System.out.println("Thanks for calculating with More Evens or More Odds?");
		System.out.println();
		
		} // moreEvensOrOdds
	
	// Helper Method: findAndCountMins
	// Description: takes in values and size, then calculates
	// and outputs the array, the minimum value, and the
	// appearances of the minimum value
	public static void findAndCountMins(int[] values, int size)
		{
		// Initialization
		int i = 0;
		int minSoFar = Integer.MAX_VALUE;
		int minCounter = 0;
		
		// Calculate Minimum Value
		for (i = 0; i < size; i++)
			if (values[i] < minSoFar)
				minSoFar = values[i];
		
		// Calculate Appearances of Minimum Value
		for (i = 0; i < size; i++)
			if (minSoFar == values[i])
				minCounter++;
		
		// Validate Negative on First Input
		if (size == 0)
			minSoFar = 0;
		
		// Output Array, Minimum Value, and Appearances of Minimum Value
		System.out.println("\nThe array contains the following values:");
		for (i = 0; i < size; i++)
			System.out.print(values[i] + " ");
		System.out.println();
		
		System.out.println("\nThe minimum value in the array is " + minSoFar);
		System.out.println("The minimum value appears " + minCounter + " times in the array");
		
		System.out.println("Thanks for calculating with How Many Mins?");
		System.out.println();
		
		} // findAndCountMins
	
} // ArraysRogers