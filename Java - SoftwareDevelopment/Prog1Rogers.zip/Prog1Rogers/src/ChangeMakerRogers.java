//
// Caleb Rogers
// Prog 1
// Due Date and Time: 2/3/20 before 9:00 a.m.
//
// Purpose: A program that calculates the accurate change back
//
// Input: Total amount of change
//
// Output: Equivalent amount in bills and coins,
// total bills, and total coins
//
// Certification of Authenticity:
// I certify that this lab is entirely my own work.

import java.util.Scanner; 

public class ChangeMakerRogers
{
	static Scanner keyboard = new Scanner(System.in);
	
	public static void main(String[] args) 
	{
		// Initialization
		int amount = 0;
		int originalAmount = 0;
		int twentys = 0;
		int tens = 0;
		int fives = 0;
		int ones = 0;
		int quarters = 0;
		int dimes = 0;
		int nickels = 0;
		int pennies = 0;
		int bills = 0;
		int coins = 0;
		int cash = 0;
		int change = 0;
	 
		// Greeting
		System.out.println("Welcome to the Change Maker system!");
		System.out.println("Enter a whole number of the total cents.");
		System.out.println("I will output a combination of bills and coins");
		System.out.println("that equals that amount of change.");
	
		// Input Change
		System.out.print("\nEnter an amount to be calculated to change: ");
		amount = keyboard.nextInt();
	
		// Calculate Change
		originalAmount = amount;
		twentys = amount / 2000;
		amount %= 2000;
		tens = amount / 1000;
		amount %= 1000;
		fives = amount / 500;
		amount %= 500;
		ones = amount / 100;
		amount %= 100;
		quarters = amount / 25;
		amount %= 25;
		dimes = amount / 10;
		amount %= 10;
		nickels = amount / 5;
		amount %= 5;
		pennies = amount;
		
		// Calculate Total Bills and Coins
		bills = twentys + tens + fives + ones;
		coins = quarters + dimes + nickels + pennies;
		
		// Output Change
		System.out.println("Your change of " + originalAmount + " can be given as:");
		
		System.out.println("\n~~~ Bills ~~~");
		if (twentys == 1)
			{
			System.out.println(twentys + " twenty");
			} //if
		else {
			System.out.println(twentys + " twentys");
			} //else
		
		if (tens == 1)
			{
			System.out.println(tens + " ten");
			} //if
		else {
			System.out.println(tens + " tens");
			} //else
		
		if (fives == 1)
			{
			System.out.println(fives + " five");
			} //if
		else {
			System.out.println(fives + " fives");
			} //else
		
		if (ones == 1)
			{
				System.out.println(ones + " one");
			} //if
		else {
			System.out.println(ones + " ones");
			} //else
		
		System.out.println("\n~~~ Coins ~~~");
		if (quarters == 1)
			{
			System.out.println(quarters + " quarter");
			} //if
		else {
			System.out.println(quarters + " quarters");
			} //else
		
		if (dimes == 1)
			{
			System.out.println(dimes + " dime");
			} //if
		else {
			System.out.println(dimes + " dimes");
			} //else
		
		if (nickels == 1)
			{
			System.out.println(nickels + " nickel");
			} //if
		else {
			System.out.println(nickels + " nickels");
			} //else
		
		if (pennies == 1)
			{
			System.out.println(pennies + " penny");
			} //if
		else {
			System.out.println(pennies + " pennies");
			} //else
		
		// Output Total Bills and Coins
		System.out.println("\nYour total bills are " + bills);
		System.out.println("Your total coins are " + coins);
		
		cash = originalAmount / 100;
		change = originalAmount % cash;
		System.out.println("Your total change back is $" + cash + "." + change);
	
		// Output Closing
		System.out.println("\nThanks for participating in Caleb's experimental program!");
		System.out.println("Goodbye");
		keyboard.close();

	} //main
} //ChangeMaker