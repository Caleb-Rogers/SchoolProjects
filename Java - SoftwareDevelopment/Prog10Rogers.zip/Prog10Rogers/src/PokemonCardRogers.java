/**
 * 
 * @author Caleb Rogers
 *
 * This is the class definition for PokemonCardRogers
 */
public class PokemonCardRogers 	
{
/**
 * Instance variable for a Pokemon's name
 */
private String myName;

/**
 * Instance variable for a Pokemon's power
 */
private int myPower;
	
	/**
	 * The default constructor for PokemonCardRogers
	 */
	public PokemonCardRogers()
		{
		myPower = 0;
		myName = "None";
		} // PokemonCardRogers
	
	/**
	 * This constructor assigns incoming variables for PokemonCardRogers
	 * @param newName	the new name for a Pokemon
	 * @param newPower	the new power for a Pokemon
	 */
	public PokemonCardRogers(int newPower, String newName)
		{
		myPower = newPower;
		myName = newName;
		} // PokemonCardRogers
	
	/**
	 * The setter for a pokemon's power
	 * @param newPrice	The incoming power for a Pokemon
	 */
	public void setPower(int newPower)
		{
		myPower = newPower;
		} // setPower
	
	/**
	 * The setter for a Pokemon's name
	 * @param newName	The incoming name for a Pokemon
	 */
	public void setName(String newName)
		{
		myName = newName;
		} // setName

	/**
	 * The getter for a Pokemon's power
	 * @return	Returns the power of a Pokemon
	 */
	public int getPower()
		{
		return myPower;
		} // getPower
	
	/**
	 * The getter for a Pokemon's name
	 * @return	Returns the name of a Pokemon
	 */
	public String getName()
		{
		return myName;
		} // getName
	
	/**
	 * This method creates a string representation of a Pokemon
	 * @return	Returns the string representation of a Pokemon
	 */
	public String toString()
		{
		String result = "Name of Pokemon: " + myName + "\n";
		result += "Power of Pokemon: " + myPower + "\n";
		return result;
		} // toString
	
} // PokemonCardRogers