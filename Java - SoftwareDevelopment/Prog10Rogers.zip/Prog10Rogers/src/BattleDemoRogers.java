/**
 * @author Caleb Rogers <br>
 * 
 * Prog 10 <br>
 * Due Date and Time: 05/04/2020 before 12:00 a.m. <br>
 * 
 * Purpose: This program plays a Pokemon Battle Game <br>
 * 
 * Input: File name.  <br>
 * 
 * Output: Player 1's Pokemon, Player 2's Pokemon, winner per round,
 * starting total cards, rounds, each players number of cards at end,
 * and the final winner. <br>
 * 
 * Certification of Authenticity: <br>
 * I certify that this lab is entirely my own work <br>
 */

import java.io.*;
import java.util.*;
import java.text.*;
	
public class BattleDemoRogers 
{
	static Scanner keyboard = new Scanner(System.in);
	static DecimalFormat moneyStyle = new DecimalFormat("0.00");

	public static void main(String[] args) 
		{
		// Initialization
		String fileName;
		File myFile;
		StackRogers play1Deck = new StackRogers();
		StackRogers play2Deck = new StackRogers();
		StackRogers discard1Deck = new StackRogers();
		StackRogers discard2Deck = new StackRogers();
		StackRogers cardTable = new StackRogers();
		int numCards = 0;
		boolean tie = false;
		boolean oneWon = false;
		int round = 0;
		int player1Cards = 0;
		int player2Cards = 0;
		boolean player1Wins = false;
		
		// Greeting
		System.out.println("Welcome to a Pokemon Battle Game!!");
				
		// File Input
		System.out.println("\nAn input file will be required to import new Pokemon");
		System.out.print("Enter a filename: ");
		fileName = keyboard.next();
		myFile = new File(fileName);
		
		// Deals Cards
		numCards = deal(myFile, play1Deck, play2Deck);
		if(play1Deck.isEmpty() == false)
			System.out.println("New Pokemon(s) have been delt to the players");
		else
			System.out.println("There was an issue! NO Pokemon have been delt out");
		
		// Plays Game
		System.out.println("\n ~~~~~~ Ready to Battle?? ~~~~~~~");
		while(((play1Deck.isEmpty()==false)||(discard1Deck.isEmpty()==false)) && ((play2Deck.isEmpty()==false)||(discard2Deck.isEmpty()==false)) && (round != 1000))
			{
			round++;
			
			// If play decks are empty, copy's from discard decks
			if(play1Deck.isEmpty() == true)
				copy(play1Deck, discard1Deck);
			if(play2Deck.isEmpty() == true)
				copy(play2Deck, discard2Deck);
			
			// Battles
			System.out.println("\n         Round " + round + ", FIGHT!");
			System.out.println("----------------------------------");
			play(play1Deck, play2Deck, cardTable);
			System.out.println("\n[Player 1 and Player 2 in Battle...]");
			
			// Check for Tie
			tie = same(cardTable, discard1Deck, discard2Deck);
			
			if(tie == false)
				{
				// Winner takes Cards
				oneWon = compare(cardTable);
				System.out.println("\n...After battle, we have a winner!!");
				if(oneWon == true)
					{
					winPlay(cardTable, discard1Deck);
					System.out.println("Player 1 has beaten player 2 in round " + round);
					} // if
				else
					{
					winPlay(cardTable, discard2Deck);
					System.out.println("Player 2 has beaten player 1 in round " + round);
					} // else
				} // if
			
			else
				{
				System.out.println("\n...After battle, we have a TIE!");
				System.out.println("Each player keeps their card");
				} // else
			
			System.out.println();
			} // while
		
		// Outputs Game's Results
		player1Cards = countCards(play1Deck) + countCards(discard1Deck);
		player2Cards = countCards(play2Deck) + countCards(discard2Deck);
		if(player1Cards > player2Cards)
			player1Wins = true;
		printResults(numCards, round, player1Cards, player2Cards, player1Wins);
		} // main
	
	public static int deal(File theFile, StackRogers p1Deck, StackRogers p2Deck)
		{
		Scanner input;
		String inputName = "None";
		int inputPower = 0;
		PokemonCardRogers inputPoke = new PokemonCardRogers(inputPower, inputName);
		int count = 0;
		
		try
			{
			input = new Scanner(theFile);
					
			while(input.hasNext())
				{
				inputPower = input.nextInt();
				inputName = input.next();
								
				inputPoke = new PokemonCardRogers(inputPower, inputName);
				if(count % 2 == 0) // validate uneven # of cards???????????????????????????????????
					p1Deck.push(inputPoke);
				else
					p2Deck.push(inputPoke);
				count++;
				} // while
							
			input.close();
			} // try
		
		catch(FileNotFoundException ex)
			{
			System.out.println("Failed to find the file: " + theFile.getAbsolutePath());
			} // catch
		catch(InputMismatchException ex)
			{
			System.out.println("Type mismatch for the number I tried to read!");
			System.out.println(ex.getMessage());
			} // catch
		catch(NumberFormatException ex)
			{
			System.out.println("Failed to convert string text into integer value!");
			System.out.println(ex.getMessage());
			} // catch
		catch(NullPointerException ex)
			{
			System.out.println("Null pointer exception");
			System.out.println(ex.getMessage());
			} // catch
		catch(Exception ex)
			{
			System.out.println("There was an error!");
			ex.printStackTrace();
			} // catch
		
		return count;
		} // fileInput
	
	public static void play(StackRogers p1Deck, StackRogers p2Deck, StackRogers theTable)
		{
		PokemonCardRogers playedCard = null;
		
		playedCard = p1Deck.pop();
		System.out.println("Player 1: " + playedCard.getName() + ", GO!!");
		theTable.push(playedCard);
		
		
		playedCard = p2Deck.pop();
		System.out.println("Player 2: " + playedCard.getName() + ", GO!!");
		theTable.push(playedCard);
		} // play
	
	public static boolean same(StackRogers theTable, StackRogers d1Deck, StackRogers d2Deck)
		{
		PokemonCardRogers p1Card = null;
		PokemonCardRogers p2Card = null;
		boolean samePower = false;
		
		p2Card = theTable.pop();
		p1Card = theTable.pop();
		
		if(p1Card.getPower() == p2Card.getPower())
			{
			samePower = true;
			d1Deck.push(p1Card);
			d2Deck.push(p2Card);
			} // if
		else
			{
			theTable.push(p1Card);
			theTable.push(p2Card);
			} // else
	
		return samePower;
		} // same
	
	public static boolean compare(StackRogers theTable)
		{
		PokemonCardRogers p1Card = null;
		PokemonCardRogers p2Card = null;
		boolean player1Wins = false;
		
		p2Card = theTable.pop();
		p1Card = theTable.pop();
		
		if(p1Card.getPower() > p2Card.getPower())
			{
			player1Wins = true;
			theTable.push(p1Card);
			theTable.push(p2Card);
			} // if
		else
			{
			theTable.push(p2Card);
			theTable.push(p1Card);
			} // else
		
		return player1Wins;
		} // compare
	
	public static void winPlay(StackRogers theTable, StackRogers theDeck)
		{
		PokemonCardRogers smallCard = null;
		PokemonCardRogers bigCard = null;
		
		smallCard = theTable.pop();
		bigCard = theTable.pop();
	
		theDeck.push(bigCard);
		theDeck.push(smallCard);	
		} // winPlay
	
	public static void copy(StackRogers playDeck, StackRogers discardDeck)
		{
		PokemonCardRogers tempCard = new PokemonCardRogers();
		StackRogers tempDeck = new StackRogers();
		
		while(discardDeck.isEmpty() == false)
			{
			tempCard = discardDeck.pop();
			tempDeck.push(tempCard);
			} // while
		
		while(tempDeck.isEmpty() == false)
			{
			tempCard = tempDeck.pop();
			playDeck.push(tempCard);
			} // while
		} // copy
	
	public static int countCards(StackRogers theDeck)
		{
		int count = 0;
		PokemonCardRogers tempCard = new PokemonCardRogers();
		StackRogers tempDeck = new StackRogers();
		
		while(theDeck.isEmpty() == false)
			{
			tempCard = theDeck.pop();
			count++;
			tempDeck.push(tempCard);
			} // while
		
		while(tempDeck.isEmpty() == false)
			{
			tempCard = tempDeck.pop();
			theDeck.push(tempCard);
			} // while
		
		return count;
		} // countCards
	
	public static void printResults(int totalCards, int plays, int p1Cards, int p2Cards, boolean winner1)
		{
		System.out.println("\nBattle Card Game Summary");
		System.out.println("============================");
		System.out.println("The game started with " + totalCards + " cards");
		System.out.println("There were " + plays + " plays in the game");
		
		if((totalCards == 0) || (p1Cards == p2Cards))
			{
			System.out.println("The winner is unclear");
			System.out.println("Player 1 ended up with " + p1Cards + " cards");
			System.out.println("Player 2 ended up with " + p2Cards + " cards");
			System.out.println("There was tie!");
			} // if
		else
			{
			System.out.println("The game ended with a clear winner");
			System.out.println("Player 1 ended up with " + p1Cards + " cards");
			System.out.println("Player 2 ended up with " + p2Cards + " cards");
			if(winner1 == true)
				System.out.println("The winner was player 1!!");
			else
				System.out.println("The winner was player 2!!");
			} // else
		} // printResults

} // BattleDemoRogers
