/**
 * 
 * @author calebrogers
 *
 *	This is the class definition for StackRogers
 */
public class StackRogers 	
{
/**
 * Instance variable for the max size of a deck
 */
private static final int MAXSIZE = 52;

/**
 * Instance variable for the list representing a deck
 */
private PokemonCardRogers[] myList;

/**
 * Instance variable for the index of the top of the deck
 */
private int myTop;

	/**
	 * The default constructor for StackRogers
	 */
	public StackRogers()
		{
		int i = 0;
		myList = new PokemonCardRogers[MAXSIZE];
		for(i = 0; i < MAXSIZE; i++)
			myList[i] = null;
		myTop = 0;
		} // Stack
	
	/**
	 * This method "pushes" a card into a deck
	 * @param thePoke	the Pokemon being pushed into a deck
	 * @return success	whether the Pokemon was "pushed" or not
	 */
	public boolean push(PokemonCardRogers thePoke)
		{
		boolean success = false;
		if(!isFull())
			{
			success = true;
			myTop++;
			myList[myTop] = thePoke;
			} // if
		return success;
		} // push
	
	/**
	 * This method "pops" a card out of a deck
	 * @return ans	The card that was "popped" out of the deck
	 */
	public PokemonCardRogers pop()
		{
		PokemonCardRogers ans = null;
		if(!isEmpty())
			{
			ans = myList[myTop];
			myTop--;
			} // if
		return ans;
		} // pop
	
	/**
	 * This method determines if a deck is empty
	 * @return whether the list is empty or not
	 */
	public boolean isEmpty()
		{
		return (myTop == 0);
		} // isEmpty
	
	/**
	 * This method determines if a deck is full
	 * @return whether the list is full or not
	 */
	public boolean isFull()
		{
		return (myTop == MAXSIZE);
		} // isFull
	
} // StackRogers
