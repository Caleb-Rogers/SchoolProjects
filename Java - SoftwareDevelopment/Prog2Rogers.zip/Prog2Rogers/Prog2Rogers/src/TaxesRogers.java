//
// Caleb Rogers
// Prog 2
// Due Date and Time: 2/10/20 before 9:00 a.m.
//
// Purpose: Calculates a users taxes.
//
// Input: Taxpayer ID, Filing Status, Gross Income,
// and Number of Exemptions.
//
// Output: Taxpayer ID, Filing Status, Taxable Income,
// Tax Rate, Total Taxes Owed, Number of Taxpayers Processed,
// Highest Tax Amount, Taxpayer ID of the Highest Tax Amount,
// Total Amount of Taxes Paid, and Average Tax Amount.
//
// Certification of Authenticity:
// I certify that this lab is entirely my own work.

import java.util.*;
import java.text.*;

public class TaxesRogers
{
	static Scanner keyboard = new Scanner(System.in);
	static DecimalFormat moneyStyle = new DecimalFormat("0.00");
	public static final int STANDARDDEDUCTION = 3250;
	public static final int EXEMPTION = 1200;
	
	public static void main(String[] args) 
	{
	
		// Initialize
		String filingStatus;
		char statusCharacter;
		char status;
		int taxID = 1;
		double grossIncome = 0;
		int numExemptions = 0;
		int totalExemptions = 0;
		double taxableIncome = 0;
		double taxRate = 0;
		double totalTax = 0;
		int numTaxpayers = 0;
		double maxTax = 0;
		int maxTaxID = 0;
		double overallTotalTax = 0;
		double avgTax = 0;
		
		// Greeting
		System.out.println("Welcome, this program will help calculate your taxes!");
		
		while (taxID != 0)
			{
			
			// Input Taxpayer ID
			System.out.println("Answer the following questions");
			System.out.print("Taxpayer ID: ");
			taxID = keyboard.nextInt();
			
			if (taxID != 0)
				{
				
				// Inputs
				do
					{
					System.out.println("(I for Individual, J for Married filing Jointly, and H for Head of household)");		
					System.out.print("Filing Status: ");
					filingStatus = keyboard.next();
					statusCharacter = filingStatus.charAt(0);
					status = Character.toUpperCase(statusCharacter);
					} //do
				while ((status != 'I') && (status != 'J') && (status != 'H'));
					
		
				System.out.print("Gross Income: ");
				grossIncome = keyboard.nextInt();
			
				System.out.print("Number of Exemptions: ");
				numExemptions = keyboard.nextInt();
				while (numExemptions < 0 || numExemptions > 10)
					{
					System.out.println("Invalid input! The number of exemptions needs to be between 0 and 10, inclusively");
					System.out.print("Number of Exemptions: ");
					numExemptions = keyboard.nextInt();
					} //while
		
				// Calculate Taxable Income
				totalExemptions = numExemptions * EXEMPTION;
				taxableIncome = grossIncome - STANDARDDEDUCTION - totalExemptions;
		
				// Calculate Tax Rate
				switch (status)
					{
					case 'I': if (taxableIncome < 17000)
								taxRate = .11;
							else if (taxableIncome <= 58000)
								taxRate = .20;
							else
								taxRate = .31;
							break;
					
					case 'J': if (taxableIncome < 20000)
								taxRate = .14;
							else if (taxableIncome <= 110000)
								taxRate = .22;
							else
								taxRate = .39;
							break;
			
					case 'H': if (taxableIncome < 34000)
								taxRate = .15;
							else if (taxableIncome <= 75000)
								taxRate = .23;
							else
								taxRate = .38;
							break;
					} // switch
			
				// Calculate Total Tax
				if (taxableIncome < 0)
					{
					taxRate = 0.0;
					totalTax = 0.0;
					} //if
				else
					totalTax = taxableIncome * taxRate;
			
				// Output per Taxpayer
				System.out.println("\nTaxpayer ID: " + taxID);
			
				if (status == 'I')
					System.out.println("Filing Status: Individual");
				else if (status == 'J')
					System.out.println("Filing Status: Married filing Jointly");
				else if (status == 'H')
					System.out.println("Filing Status: Head of household");
			
				System.out.println("Taxable Income: $" + moneyStyle.format(taxableIncome));
				DecimalFormat tax = new DecimalFormat("#%");
			    System.out.println("Tax Rate: " + tax.format(taxRate));
				System.out.println("Total Taxes Owed: $" + moneyStyle.format(totalTax));
				
				// Calculate Summary
				numTaxpayers++;
				
				if (totalTax > maxTax)
					{
					maxTax = totalTax;
					maxTaxID = taxID;
					} //if
					
				overallTotalTax += totalTax;
				System.out.println();
				} //if
			
			else
				{
				if (numTaxpayers == 0)
					avgTax = 0;
				else
					avgTax = overallTotalTax / numTaxpayers;
					
				// Output Summary
				System.out.println("\n~~~Summary~~~");
				System.out.println("Number of Taxpayers Processed: " + numTaxpayers);
				System.out.println("Highest Tax Amount: $" + moneyStyle.format(maxTax));
				System.out.println("Taxpayer ID of the Highest Tax Amount: " + maxTaxID);	
				System.out.println("Total Amount of Taxes Paid: $" + moneyStyle.format(overallTotalTax));
				System.out.println("Average Tax Amount: $" + moneyStyle.format(avgTax));
				
				// Output Closing
				System.out.println("\nThanks for participating in Caleb's experimental program!");
				System.out.println("Goodbye");
				keyboard.close();
				} //else
			} //while
		} //main
	} //TaxesRogers