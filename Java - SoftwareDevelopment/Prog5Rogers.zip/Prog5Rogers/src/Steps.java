public class Steps 
	{
	private int myStepWidth;
	private int myNumSteps;
	private char myFillStyle;
	
	public Steps()
		{
		myStepWidth = 0;
		myNumSteps = 0;
		myFillStyle = ' ';
		} // Steps
	 
	public Steps(int newStepWidth, int newNumSteps, char newFillStyle)
		{
		myStepWidth = newStepWidth;
		myNumSteps = newNumSteps;
		myFillStyle = newFillStyle;
		} // Steps
	
	public int getStepWidth()
		{
		return myStepWidth;
		} // getStepWidth

	public int getNumSteps()
		{
		return myNumSteps;
		} // getNumSteps

	public char getFillStyle()
		{
		return myFillStyle;
		} // getFillStyle
	
	public void setStepWidth(int newStepWidth)
		{
		myStepWidth = newStepWidth;
		} // setStepWidth
	
	public void setNumSteps(int newNumSteps)
		{
		myNumSteps = newNumSteps;
		} // setNumSteps
	
	public void setFillStyle(char newFillStyle)
		{
		myFillStyle = newFillStyle;
		} // setFillStyle
	
	public String toString()
		{
		String result = "Step Width: " + myStepWidth + "\n";
		result += "Number of Steps: " + myNumSteps +"\n";
		result += "Fill Style: " + myFillStyle;
		return result;
		} // toString
	
	public int calcArea()
		{
		int theArea = 0;
		theArea = myStepWidth * myNumSteps;
		return theArea;
		} // calcArea
	
	public void drawSteps()
		{
		int i = 0;
		int j = 0;
		int increase = 0;
		for(i = 0; i < myNumSteps; i++)
			{
			for(j = 0; j < myStepWidth + increase; j++)
				System.out.print(myFillStyle);
			System.out.println();
			increase += myStepWidth;
			} // for i
		} // drawSteps
	
	public void drawThickSteps()
		{
		int i = 0;
		int j = 0;
		int k = 0;
		int increase = 0;
		for (i = 0; i < myNumSteps; i++)
			{
			for(j = 0; j < (myStepWidth); j++)
				{
				for(k = 0; k < (myStepWidth + increase); k++)
					System.out.print(myFillStyle);
				System.out.println();
				} // for j
			increase += myStepWidth;
			} // for i
		} // drawThickSteps
	
	} // Steps