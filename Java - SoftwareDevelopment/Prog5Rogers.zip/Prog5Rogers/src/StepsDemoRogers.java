// Caleb Rogers
// Prog 5
// Due Date and Time: 03/02/20 before 9:00 a.m.
//
// Purpose: This program modifies and displays steps
//
// Input: Menu choice, step width, number of steps, and fill style
//
// Output: Menu, area, step width, number of steps, fill style,
// and a picture of the steps
//
// Certification of Authenticity:
// I certify that this lab is entirely my own work.
//
import java.util.Scanner;

public class StepsDemoRogers 
{
	static Scanner keyboard = new Scanner(System.in);
	
	public static void main(String[] args) 
	{
		// Initialization
		Steps theSteps = new Steps(2, 5, '*');
		String menuChoice;
		char menu;
		int width = 0;
		int numberOfSteps = 0;
		String fill;
		char fillStyle;
		int area = 0;
		
		// Greeting
		System.out.println("Welcome, this program will present different options to modify and display steps!");
		
		do 
			{
			// Menu
			System.out.println();
			System.out.println("{Select a choice from the following menu}");
			System.out.println("'W': Assign the Step Width");
			System.out.println("'N': Assign the Number of Steps");
			System.out.println("'F': Assign the Fill Style");
			System.out.println("'A': Calculate the Area");
			System.out.println("'T': Text Description of the Steps");
			System.out.println("'D': Draw the Steps");
			System.out.println("'X': Draw Thick Steps");
			System.out.println("'Q': Quit Program");
			
			// Menu Choice
			System.out.print("Enter your menu choice: ");
			menuChoice = keyboard.next();
			menu = menuChoice.charAt(0);
			menu = Character.toUpperCase(menu);
			System.out.println();
			
			// Menu Selection
			switch (menu)
				{
				case 'W': System.out.println("Input a positive integer to assign the step width");
						System.out.print("Enter value: ");
						width = keyboard.nextInt();
						
						while (width <= 0)
							{
							System.out.println("Invalid input! Input a positive integer!");
							System.out.print("Enter value: ");
							width = keyboard.nextInt();
							} // while
						
						theSteps.setStepWidth(width);
						System.out.println("\nYour step's width has been updated to " + width);
						break;
				
				case 'N': System.out.println("Input a positive integer to assign the number of steps");
						System.out.print("Enter value: ");
						numberOfSteps = keyboard.nextInt();
						
						while (numberOfSteps <= 0)
							{
							System.out.println("Invalid input! Input a positive integer!");
							System.out.print("Enter value: ");
							numberOfSteps = keyboard.nextInt();
							} // while
						
						theSteps.setNumSteps(numberOfSteps);
						System.out.println("\nYour number of steps has been updated to " + numberOfSteps);
						break;
					
				case 'F': System.out.println("Input a single character to assign a fill style");
						System.out.print("Enter value: ");
						fill = keyboard.next();
						fillStyle = fill.charAt(0);
						theSteps.setFillStyle(fillStyle);
						System.out.println("\nYour fill style has been updated to " + fillStyle);
						break;
					
				case 'A': area = theSteps.calcArea();
						System.out.println("The area of the steps is " + area);
						break;
					
				case 'T': System.out.println("The following describes the steps");
						System.out.println(theSteps.toString());
						System.out.println("Area: " + theSteps.calcArea());
						break;
					
				case 'D': theSteps.drawSteps();
						break;
				
				case 'X': theSteps.drawThickSteps();
						break;
						
				case 'Q': System.out.println("Thanks for participating in Caleb's experimental program!");
						System.out.println("Goodbye");
						keyboard.close();
						break;
						
				default: System.out.println("Invalid input! Enter an option from the menu ");
						break;
				} // switch
			
			} // do
		while (menu != 'Q');	

	} // main

}// StepsDemoRogers
