//
// Caleb Rogers
// Prog 3
// Due Date and Time: 2/17/20 before 9:00 a.m.
//
// Purpose: Processes insurance payments for a hospital.
//
// Input: Patient ID, household income, insurance plan, and number of days.
//
// Output: Patient ID, household income, insurance plan, number of days, 
// admittance fee, per diem rate, service fee, discount, total bill per patient
// number of patients processed, highest bill amount, patient ID associated with
// highest bill amount, lowest bill amount, patient ID associated with lowest
// bill amount, total cost of all bills processed, and average bill cost.
//
// Certification of Authenticity:
// I certify that this lab is entirely my own work.

import java.util.*;
import java.text.*;

public class HospitalRogers 
{
	static Scanner keyboard = new Scanner(System.in);
	static DecimalFormat moneyStyle = new DecimalFormat("0.00");
	public static final int ADMITTANCE = 500;
	
	public static void main(String[] args) 
	{
		
	// Initialize
	int patientID = 0;
	double income = 0;
	String insurancePlan;
	char insuranceCharacter;
	char insurance;
	int numDays = 0;
	double perDiem = 0;
	double serviceFee = 0;
	double discount = 0;
	double totalBill = 0;
	int numPatients = 0;
	double maxBill = Double.MIN_VALUE;
	int maxID = 0;
	double minBill = Double.MAX_VALUE;
	int minID = 0;
	double overallTotal = 0;
	double average = 0;
		
	// Greeting
	System.out.println("Welcome, this program will help you process insurance payments at the Hospital!");
	
	// Input ID
	System.out.println("Please answer the following questions");
	System.out.print("Patient ID: ");
	patientID = keyboard.nextInt();
	
	while (patientID != 0)	
		{
		
		// Inputs
		System.out.print("Household Income: ");
		income = keyboard.nextDouble();
		while (income < 0)
			{
			System.out.println("Invalid Input! Input must be a positive integer");
			System.out.print("Re-Enter Household Income: ");
			income = keyboard.nextDouble();
			} //while
		
		do
			{
			System.out.println("('B' for Blue Plus, 'M' for Med-Health, 'H' for Health Plan, and 'N' for No Insurance)");		
			System.out.print("Insurance Plan: ");
			insurancePlan = keyboard.next();
			insuranceCharacter = insurancePlan.charAt(0);
			insurance = Character.toUpperCase(insuranceCharacter);
			} //do
		while ((insurance != 'B') && (insurance != 'M') && (insurance != 'H') && (insurance != 'N'));
		
		System.out.print("Number of Days Admitted: ");
		numDays = keyboard.nextInt();
		while ((numDays < 1) || (numDays > 365))
			{
			System.out.println("Invalid Input! Input must be an integer between 1 and 365, inclusively");
			System.out.print("Re-Enter Number of Days Admitted: ");
			numDays = keyboard.nextInt();
			} // While
		
		// Calculates Per Diem
		perDiem = calcPerDiem(insurance, income);
		
		// Calculates Service Fee
		serviceFee = calcServiceFee(perDiem, numDays);
		
		// Calculates Discount
		if (numDays > 25)
			discount = calcDiscount(numDays);
		
		// Calculates Total Bill
		totalBill = calcTotalBill(serviceFee, discount);
		
		// Outputs Results per Taxpayer
		outputResults(patientID, income, insurance, numDays, ADMITTANCE, perDiem, serviceFee, discount, totalBill);
				
		// Calculate Summary
		numPatients++;
		
		if (totalBill > maxBill)
			{
			maxBill = totalBill;
			maxID = patientID;
			} // If
		
		if (totalBill < minBill)
			{
			minBill = totalBill;
			minID = patientID;
			} // If
		
		overallTotal += totalBill;
		
		// Input ID
		if (patientID != 0)
			{
			System.out.println("\nPlease answer the following questions");
			System.out.print("Patient ID: ");
			patientID = keyboard.nextInt();
			} // If
		
		} // While
	
	// Validate 0 Patients
	if (numPatients == 0)
		{
		minBill = 0;
		overallTotal = 0;
		average = 0;
		} // if
	else
		// Calculate Summary (average)
		average = overallTotal / numPatients;

	// Output Summary
	System.out.println("\n~~~Summary~~~");
	System.out.println("Number of Patients Processed: " + numPatients);
	System.out.println("Highest Bill Amount: $" + moneyStyle.format(maxBill));
	System.out.println("Patient's ID of the Highest Bill Amount: " + maxID);
	System.out.println("Lowest Bill Amount: $" + moneyStyle.format(minBill));
	System.out.println("Patient's ID of the Lowest Bill Amount: " + minID);
	System.out.println("Total Cost of All Bills Processed: $" + moneyStyle.format(overallTotal));
	System.out.println("Average Bill Cost: $" + moneyStyle.format(average));
	
	// Output Closing
	System.out.println("\nThanks for participating in Caleb's experimental program!");
	System.out.println("Goodbye");
	keyboard.close();
	
	} // Main
	
	public static double calcPerDiem(char theInsurancePlan, double householdIncome)
		{
		double perDiem = 0;
		
		switch (theInsurancePlan)
			{
			case 'B': if (householdIncome < 15000)
						perDiem = 50;
					else if (householdIncome <= 67500)
						perDiem = 85;
					else
						perDiem = 150;
					break;
					
			case 'M': if (householdIncome < 20000)
						perDiem = 65;
					else if (householdIncome <= 75000)
						perDiem = 100;
					else
						perDiem = 200;
					break;
					
			case 'H': if (householdIncome < 17500)
						perDiem = 55;
					else if (householdIncome <= 63000)
						perDiem = 90;
					else
						perDiem = 150;
					break;
					
			case 'N': perDiem = 500;
					break;		
			} // Switch
		
		return perDiem;
		} // calcPerDiem
	
	public static double calcServiceFee(double perDiemRate, int days)
		{
		double serviceFee = 0;
		serviceFee = perDiemRate * days;
		return serviceFee;
		} // calcServiceFee
	
	public static double calcDiscount(int days)
		{
		int weeks = 0;
		double discount = 0;
		
		weeks = days / 7;
		discount = weeks * 300;
		
		return discount;
		} // calcDiscount
	
	public static double calcTotalBill(double fee, double discountAmount)
		{
		double totalBill = 0;
		totalBill = (fee + ADMITTANCE) - discountAmount;
		return totalBill;
		} // calcTotalBill
	
	public static void outputResults(int idNum, double householdIncome, char theInsurancePlan, int days, int ADMITTANCE, double perDiemRate, double fee, double discountAmount, double total)
		{
		System.out.println("\nPatient ID: " + idNum);
		System.out.println("Household Income: $" + moneyStyle.format(householdIncome));
		
		if (theInsurancePlan == 'B')
			System.out.println("Insurance Plan: Blue Plus");
		else if (theInsurancePlan == 'M')
			System.out.println("Insurance Plan: Med-Health");
		else if (theInsurancePlan == 'H')
			System.out.println("Insurance Plan: Health Plan");
		else if (theInsurancePlan == 'N')
			System.out.println("Insurance Plan: No Insurance");
		
		System.out.println("Number of Days Admittted: " + days);
		System.out.println("Admittance Fee: $" + moneyStyle.format(ADMITTANCE));
		System.out.println("Per Diem Rate: $" + moneyStyle.format(perDiemRate));
		System.out.println("Service Fee: $" + moneyStyle.format(fee));
		System.out.println("Discount: $" + moneyStyle.format(discountAmount));
		System.out.println("Total Bill: $" + moneyStyle.format(total));
		} // outputResults
	
} // HospitalRogers
