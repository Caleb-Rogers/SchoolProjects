"""
File: itemRogers.py
<Resources to modify shopping lists>
"""

class Item:

    def __init__(self, initalName, initalQuantity, initalUnitPrice):
        """Initalizes the instance variables"""
        self.myName = initalName
        self.myQuantity = initalQuantity
        self.myUnitPrice = initalUnitPrice

    def __str__(self):
        "Returns a string representation of an item"
        result = "Item's Name: " + self.myName + "\n"
        result = result + "Item's quantity: " + str(self.myQuantity) + "\n"
        result = result + "Item's unit price: ${0:0.2f}".format(self.myUnitPrice)
        return result

    def getName(self):
        """Returns the name of the item"""
        return self.myName
    
    def getQuantity(self):
        """Returns the quantity of the item"""
        return self.myQuantity
    
    def getUnitPrice(self):
        """Returns the unit price of the item"""
        return self.myUnitPrice
    
    def setName(self, newName):
        """Sets the name of the item"""
        self.myName = newName
        
    def setQuantity(self, newQuantity):
        """Sets the quantity of the item"""
        self.myQuantity = newQuantity
        
    def setUnitPrice(self, newUnitPrice):
        """Sets the unit price of the item"""
        self.myUnitprice = newUnitPrice

