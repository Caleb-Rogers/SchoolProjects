##
## Name: Caleb Rogers
## Prog9Rogers.py
##
## Purpose:
## This program uses uses an array of objects to create and
## modify a shopping list
##
## Inputs:
## File name; Menu choice ("1", "2", "3", "4", "5", "6", "7", "8", or "0"),
## name, quantity, and unit price for new item for "1"; name and quantity
## of item to be deleted for "2"; and name of item to be found for "4"; 
## 
##
## Output:
## Name, quantity, and unit price of each item for "3"; searched item for "4"
## count of the total quantity of the items for "5"; total cost of the items
## for "6"; and whether or not the list is empty for "7"
## 
## Certification of Authenticity:
## I certify that this lab is entirely my own work.
##

from itemRogers import Item

def main():

    # Initialization
    itemList = []
    choice = "Z"

    # Greeting
    print("WELCOME TO SCAM'S WAREHOUSE CLUB!!")
    print("This program will present options to create and modify your shopping list!")
    print()

    # Get input file and open file
    fileName = input("Enter the file name, including the suffix: ")
    theFile = open(fileName, "r")
    print("Thank you, please proceed by picking from one of the options below")
    print()
    

    # Get number of items from file
    numItems = int(theFile.readline())

    for i in range(numItems):

        # Get data from input file
        name = theFile.readline().strip()
        quantity = int(theFile.readline())
        price = float(theFile.readline())

        # Create a item object and add to the shopping list
        initalItems = Item(name, quantity, price)
        itemList.append(initalItems)

        
    while choice.upper() != "0":

        # Menu and Choice
        print("Choose an option")
        print("1. Add an item")
        print("2. Delete an item from the list")
        print("3. Print each item in the list")
        print("4. Search for a user-specified item in the list")
        print("5. Count the total number of items in the list")
        print("6. Total the cost of the items in the list")
        print("7. Determine whether the list is empty")
        print("8. Clear the list")
        print("0. Quit")

        choice = input("Enter your choice: ")
        print()

        if choice == "1":
            
            print("Enter the following information about the item you want to add")

            # Input new item
            name = input("Input Name: ")
            
            quantity = int(input("Input Quantity: "))
            while quantity <= 0:
                print("The entered quantity was not valid")
                quantity = int(input("Input a positive, whole number for your quantity: "))
                
            price = float(input("Input Unit Price: "))
            while price < 0:
                print("The entered unit price was not valid")
                price = float(input("Input a positive number for your unit price: "))

            # Adds item to list
            itemList = addItem(itemList, name, quantity, price)
            print("Your item,", name + ", has been added to your shopping list")
            print()

        elif choice == "2":

            # Input item to be deleted
            delete = input("Enter the name of an item you want to delete from your shopping list: ")

            # Validates if item is in list
            validated = validateItem(itemList, delete)
            if validated is False:
                print("The item entered was not found in your shopping list")

            else:
                # Removes item from list
                howMany = int(input("How many of the entered item do you want to delete: "))
                while howMany <= 0:
                    howMany = int(input("Invalid input, enter a positive, whole number for your quantity: "))
                numDeleted = deleteItem(itemList, delete, howMany)
                print("The quantity", numDeleted, "of the item", delete, "has been deleted from the list")
            print()

        elif choice == "3":

            # Validate if list is empty
            empty = emptyList(itemList)
            if empty is True:
                print("Your shopping list is empty")

            else:
                # Outputs the items in the list
                printItems(itemList)
            print()

        elif choice == "4":

            # Input item to be found and determines and outputs if item is in the list
            findItem = input("Enter the name of an item you want to find in your shopping list: ")
            search = searchItem(itemList, findItem)
            print()

        elif choice == "5":

            # Calculates and outputs the number of items in the list
            numItems = countItems(itemList)
            print("There are", numItems, "items in your shopping list")
            print()

        elif choice == "6":

            # Calculates and outputs the total price of the items in the list
            itemsTotal = totalPriceOfItems(itemList)
            print("The total of the items in your shopping list is ${0:0.2f}".format(itemsTotal))
            print()
            
        elif choice == "7":

            # Calculates and outputs whether or not there are items in the list
            empty = emptyList(itemList)
            if empty is True:
                print("There are NO items in your shopping cart")
                print("Your shopping list is empty")
            else:
                print("There are items in your shopping cart")
                print("Your shopping list is NOT empty")
            print()

        elif choice == "8":

            # Removes all items from the list
            clearList(itemList)
            print("All the items from your list has been removed")
            print()

        elif choice != "0":

            # Validate menu choice
            print("Invalid input, enter a number from the following menu")
            print()
            
    print("Thank you for participating in Caleb's experimental program")
    theFile.close()

# function: addItem()
#
# adds an item to the list
#
# Parameters:
# (theList) = holds the shopping list which is an array of objects
# (newName) = holds the name of the item to be added
# (newQuantity) = holds the quantity of the item to be added
# (newPrice) = holds the unit price of the item to be added
#
# Returns: the shopping list
def addItem(theList, newName, newQuantity, newPrice):
    newItem = Item(newName, newQuantity, newPrice)
    theList.append(newItem)
    return theList

# function: deleteItem()
#
# deletes an item from the list
#
# Parameters:
# (theList) = holds the shopping list which is an array of objects
# (theItem) = holds the name of the item to be deleted
# (numDelete) = holds the quantity of the item to be deleted
#
# Returns: the quantity of the item deleted
def deleteItem(theList, theItem, numDelete):
    for value in theList:
        if theItem == value.getName():
            while (value.getQuantity() - numDelete) < 0:
                print()
                print("The entered quantity is more than the quantity in your shopping list")
                numDelete = int(input("Enter a valid number: "))
            quantity = value.getQuantity() - numDelete
            if quantity == 0:
                theList.remove(value)
            else:
                value.setQuantity(quantity)
    return numDelete

# function: validateItem()
#
# validates if an item is in the list
#
# Parameters:
# (theList) = holds the shopping list which is an array of objects
# (theItem) = holds the name of the item to be validated
#
# Returns: True or False based on whether the entered item is in the list or not
def validateItem(theList, theItem):
    ans = False
    for value in theList:
        if theItem == value.getName():
            ans = True
    return ans

# function: printItems()
#
# outputs the name, quantity, and unit price of all the items
#
# Parameters:
# (theList) = holds the shopping list which is an array of objects
#
# Returns: none
def printItems(theList):
    for value in theList:
        print(value)
        print("~~~~~~~~~~~~~~~~~~~~~~~~~~")

# function: searchItem()
#
# Determines and outputs whether the entered item is in the list or not
#
# Parameters:
# (theList) = holds the shopping list which is an array of objects
# (theItem) = holds the name of the item to be found
#
# Returns: none
def searchItem(theList, theItem):
    ans = False
    trueQuantity = 0
    trueUnitPrice = 0.00
    for value in theList:
        if theItem == value.getName():
            ans = True
            trueQuantity = value.getQuantity()
            trueUnitPrice = value.getUnitPrice()
    if ans is True:
        print("The item", theItem, "is currently in your shopping list")
        print("There is a quantity of", trueQuantity, "at ${0:0.2f}".format(trueUnitPrice), "per", theItem)
    else:
        print("The item", theItem, "is not present in your shopping list")

# function: countItems()
#
# Counts how many items are in the list
#
# Parameters:
# (theList) = holds the shopping list which is an array of objects
#
# Returns: the total quantity of the items in the list
def countItems(theList):
    totalQuantity = 0
    for value in theList:
        totalQuantity += value.getQuantity()
    return totalQuantity

# function: totalPriceOfItems()
#
# Calculates the total price of the items in the list
#
# Parameters:
# (theList) = holds the shopping list which is an array of objects
#
# Returns: the total price of the items in the list
def totalPriceOfItems(theList):
    total = 0
    for value in theList:
        price = (value.getUnitPrice()) * (value.getQuantity())
        total += price
    return total

# function: emptyList()
#
# Determines whether the list is empty or not
#
# Parameters:
# (theList) = holds the shopping list which is an array of objects
#
# Returns: True or False based on whether the list is empty or not
def emptyList(theList):
    ans = False
    if len(theList) == 0:
        ans = True
    return ans

# function: clearList()
#
# removes all the items from the list, making the list empty
#
# Parameters:
# (theList) = holds the shopping list which is an array of objects
#
# Returns: none
def clearList(theList):
    theList.clear()

main()
