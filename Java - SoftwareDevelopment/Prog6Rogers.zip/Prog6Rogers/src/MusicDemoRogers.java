/**
 * @author Caleb Rogers <br>
 * 
 * Prog 6 <br>
 * Due Date and Time: 03/12/20 before 9:00 a.m. <br>
 * 
 * Purpose: This program uses classes and arrays of objects to modify
 * a playlist of songs. <br>
 * 
 * Input: Menu choice, song's name, song's artist, song's number of minutes,
 * song's number of seconds, song's and song's price <br>
 * 
 * Output: Longest song, shortest song, number of songs, total cost of songs,
 * and every song's name, artist, number of minutes, number of seconds, and
 * price in a playlist <br>
 * 
 * Certification of Authenticity: <br>
 * I certify that this lab is entirely my own work,
 * but i discussed it with Madeline Atwood <br>
 */

import java.util.*;
import java.text.*;

public class MusicDemoRogers
{
	
	static Scanner keyboard = new Scanner(System.in);
	static DecimalFormat moneyStyle = new DecimalFormat("0.00");
	
	public static void main(String[] args) 
	{
		// Initialization
		String menuChoice;
		char menu;
		String songName;
		String songArtist;
		int numMinutes = 0;
		int numSeconds = 0;
		double thePrice = 0.0;
		PlaylistRogers thePlaylist = new PlaylistRogers();
		boolean added = false;
		SongRogers longestSong = null;
		SongRogers shortestSong = null;
		int numSongs = 0;
		double totalCost = 0.0;
		boolean deleted = false;
		
		// Greeting
		System.out.println("Welcome, this program will present different options to modify songs in a playlist!");

		do 
			{
			// Menu
			System.out.println();
			System.out.println("{Select a choice from the following menu}");
			System.out.println("'A': Add a Song to the Playlist");
			System.out.println("'L': Find the Longest Song in the Playlist");
			System.out.println("'S': Find the Shortest Song in the Playlist");
			System.out.println("'N': Find the Number of Songs in the Playlist");
			System.out.println("'T': Find the Total Cost of all Songs in the Playlist");
			System.out.println("'P': Print out Details about all Songs in the Playlist");
			System.out.println("'D': Delete the Longest Song from the Playlist");
			System.out.println("'Q': Quit Program");
			
			// Menu Choice
			System.out.print("Enter your menu choice: ");
			menuChoice = keyboard.next();
			menu = menuChoice.charAt(0);
			menu = Character.toUpperCase(menu);
			System.out.println();
			
			// Menu Selection
			switch (menu)
				{
				case 'A': System.out.println("Want to add a song to your playlist?");
						System.out.println("Input the following information");
						
						System.out.print("Enter the name of the song: ");
						songName = keyboard.next();
						
						System.out.print("Enter the artist of the song: ");
						songArtist = keyboard.next();
						
						System.out.print("Enter the number of minutes in runtime: ");
						numMinutes = keyboard.nextInt();
						while (numMinutes < 0)
							{
							System.out.print("Invalid input! Enter a positive integer: ");
							numMinutes = keyboard.nextInt();
							} // while
						
						System.out.print("Enter the number of seconds in runtime: ");
						numSeconds = keyboard.nextInt();
						if (numMinutes == 0)
							while ((numSeconds <= 0) || (numSeconds > 59))
							{
							System.out.print("Invalid input! Enter a integer between 1 and 59, inclusively: ");
							numSeconds = keyboard.nextInt();
							} // while
						else
							while ((numSeconds < 0) || (numSeconds > 59))
							{
							System.out.print("Invalid input! Enter a integer between 0 and 59, inclusively: ");
							numSeconds = keyboard.nextInt();
							} // while
						
						System.out.print("Enter the download price of the song: ");
						thePrice = keyboard.nextDouble();
						while (thePrice < 0)
							{
							System.out.print("Invalid input! Enter a positive number: ");
							numMinutes = keyboard.nextInt();
							} // while
						
						SongRogers theSong = new SongRogers(songName, songArtist, numMinutes, numSeconds, thePrice);
						added = thePlaylist.addToPlaylist(theSong);
						
						if (added == true)
							System.out.println("\nThe song " + songName + " was added to the playlist");
						else
							System.out.println("\nThere was an issue! The song " + songName + " was NOT added to the playlist");
						break;
				
				case 'L': System.out.println("Want to find the longest song to your playlist?");
						longestSong = thePlaylist.findLongest();
						if (longestSong != null)
							{
							System.out.println("The longest song in the playlist is " + longestSong.getName());
							System.out.println("The artist of the longest song is " + longestSong.getArtist());
							System.out.println("The longest runtime is " + String.format("%d:%02d", longestSong.getMinutes(), longestSong.getSeconds()));
							System.out.println("The price of the longest song is $" + moneyStyle.format(longestSong.getPrice()));
							} // if
						else
							{
							System.out.println("\nUnable to find the longest song");
							System.out.println("Make sure there are songs in your playlist!");
							} // else
						break;
					
				case 'S': System.out.println("Want to find the shortest song to your playlist?");
						shortestSong = thePlaylist.findShortest();
						if (shortestSong != null)
							{
							System.out.println("The shortest song in the playlist is " + shortestSong.getName());
							System.out.println("The artist of the shortest song is " + shortestSong.getArtist());
							System.out.println("The shortest runtime is " + String.format("%d:%02d", shortestSong.getMinutes(), shortestSong.getSeconds()));
							System.out.println("The price of the shortest song is $" + moneyStyle.format(shortestSong.getPrice()));
							} // if
						else
							{
							System.out.println("\nUnable to find the shortest song");
							System.out.println("Make sure there are songs in your playlist!");
							} // else
						break;
					
				case 'N': System.out.println("Want to find the number of songs to your playlist?");
						numSongs = thePlaylist.getSize();
						System.out.println("The number of songs in the playlist is " + numSongs);
						break;
					
				case 'T': System.out.println("Want to find the total cost of the songs to your playlist?");
						totalCost = thePlaylist.calcTotal();
						System.out.println("The total cost of all the songs in the playlist is $" + moneyStyle.format(totalCost));
						break;
					
				case 'P': System.out.println("The following represents all the songs in your playlist!");
						if (thePlaylist.getSize() == 0)
							System.out.println("There are currently no songs in the playlist!");
						else
							thePlaylist.printFullPlaylist();
						break;
				
				case 'D': System.out.println("Want to delete the longest song to your playlist?");
						deleted = thePlaylist.deleteLongest();
						if (deleted == true)
							System.out.println("The longest song in the playlist was deleted");
						else
							{
							System.out.println("Unable to delete the longest song");
							System.out.println("Make sure there are songs in your playlist!");
							} // else
						break;
						
				case 'Q': System.out.println("Thanks for participating in Caleb's experimental program!");
						System.out.println("Goodbye");
						keyboard.close();
						break;
						
				default: System.out.println("Invalid input! Enter an option from the menu ");
						break;
				} // switch
			} // do
		while (menu != 'Q');	
	} // main
} // MusicDemoRogers
