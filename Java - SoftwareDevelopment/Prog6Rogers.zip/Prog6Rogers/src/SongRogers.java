/**
 * 
 * @author Caleb Rogers <br>
 *
 * This is the class definition for SongRogers
 */

import java.text.*;

public class SongRogers 
{
/**
 * Instance variable for song's name
 */
private String myName;
/**
 * Instance variable for song's artist
 */
private String myArtist;
/**
 * Instance variable for song's minutes
 */
private int myMinutes;
/**
 * Instance variable for song's seconds
 */
private int mySeconds;
/**
 * Instance variable for song's price
 */
private double myPrice;

	static DecimalFormat moneyStyle = new DecimalFormat("0.00");

	/**
	 * The default constructor for SongRogers
	 */
	public SongRogers()
		{
		myName = "None";
		myArtist = "None";
		myMinutes = 0;
		mySeconds = 0;
		myPrice = 0.0;
		} // SongRogers
	
	/**
	 * This constructor assigns incoming variables for SongRogers
	 * @param newName		The new name for a song
	 * @param newArtist		The new artist for a song
	 * @param newMinutes	The new minutes for a song
	 * @param newSeconds	The new seconds for a song
	 * @param newPrice		The new price for a song
	 */
	public SongRogers(String newName, String newArtist, int newMinutes, int newSeconds, double newPrice)
		{
		myName = newName;
		myArtist = newArtist;
		myMinutes = newMinutes;
		mySeconds = newSeconds;
		myPrice = newPrice;
		} // SongRogers
	
	/**
	 * The setter for a song's name
	 * @param newName	The incoming name for a song
	 */
	public void setName(String newName)
		{
		myName = newName;
		} // setName
	
	/**
	 * The setter for a song's artist
	 * @param newArtist	The incoming artist for a song
	 */
	public void setArtist(String newArtist)
		{
		myArtist = newArtist;
		} // setArtist
	
	/**
	 * The setter for a song's minutes
	 * @param newMinutes	The incoming minutes for a song
	 */
	public void setMinutes(int newMinutes)
		{
		myMinutes = newMinutes;
		} // setMinutes
	
	/**
	 * The setter for a song's seconds
	 * @param newSeconds	The incoming seconds for a song
	 */
	public void setSeconds(int newSeconds)
		{
		mySeconds = newSeconds;
		} // setSeconds
	
	/**
	 * The setter for a song's price
	 * @param newPrice	The incoming price for a song
	 */
	public void setPrice(double newPrice)
		{
		myPrice = newPrice;
		} // setPrice
	
	/**
	 * The getter for a song's name
	 * @return	Returns the name of a song
	 */
	public String getName()
		{
		return myName;
		} // getName
	
	/**
	 * The getter for a song's artist
	 * @return	Returns the artist of a song
	 */
	public String getArtist()
		{
		return myArtist;
		} // getArtist
	
	/**
	 * The getter for a song's minutes
	 * @return	Returns the minutes of a song
	 */
	public int getMinutes()
		{
		return myMinutes;
		} // getMinutes
	
	/**
	 * The getter for a song's seconds
	 * @return	Returns the seconds of a song
	 */
	public int getSeconds()
		{
		return mySeconds;
		} // getSeconds
	
	/**
	 * The getter for a song's price
	 * @return	Returns the price of a song
	 */
	public double getPrice()
		{
		return myPrice;
		} // getPrice
	
	/**
	 * This method creates a string representation of a song
	 * @return	Returns the string representation of a song
	 */
	public String toString()
		{
		String result = "Name of Song: " + myName + "\n";
		result += "Name of Artist: " + myArtist + "\n";
		//result += "Runtime: " + myMinutes + ":" + mySeconds + "\n";
		result += "Runtime: " + String.format("%d:%02d", myMinutes, mySeconds) + "\n";
		result += "Download Price of Song: $" + moneyStyle.format(myPrice);
		return result;
		} // toString
	
} // SongRogers
