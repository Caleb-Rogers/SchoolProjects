/**
 * 
 * @author Caleb Rogers <br>
 * 
 * This is the class definition for PlaylistRogers
 */
public class PlaylistRogers 
{
/**
 * Instance variable for the array of songs in the playlist
 */
private SongRogers[] mySongs;
/**
 * Instance variable for the number of songs in the playlist
 */
private int mySize;

	/**
	 * The default constructor for PlaylistRogers
	 */
	public PlaylistRogers()
		{
		int i = 0;
		mySongs = new SongRogers[10];
		for (i = 0; i < 10; i++)
			mySongs[i] = null;
		mySize = 0;
		} // PlaylistRogers
	
	/**
	 * The getter for the playlist's size
	 * @return	The size of the playlist
	 */
	public int getSize()
		{
		return mySize;
		} // getSize
	
	/**
	 * This method adds a new song to the playlist
	 * @param newSong	The new song that is added to the playlist
	 * @return			Returns whether the song was added or not
	 */
	public boolean addToPlaylist(SongRogers newSong)
		{
		boolean added = false;
		if (mySize < mySongs.length)
			{
			mySongs[mySize] = newSong;
			mySize++;
			added = true;
			} // if
		return added;
		} // addToPlaylist
	
	/**
	 * This method finds the song with the longest runtime
	 * @return	Returns the longest song
	 */
	public SongRogers findLongest()
		{
		SongRogers longestSong = null;
		double maxTime = Double.MIN_VALUE;
		int i = 0;
		for (i = 0; i < mySize; i++)
			{
			if (((mySongs[i].getMinutes() * 60) + (mySongs[i].getSeconds())) > maxTime)
				{
				maxTime = (mySongs[i].getMinutes() * 60) + (mySongs[i].getSeconds());
				longestSong = mySongs[i];
				} // if
			} // for
		
		return longestSong;
		} // findLongest
	
	/**
	 * This method finds the song with the shortest runtime
	 * @return	Returns the shortest song
	 */
	public SongRogers findShortest()
		{
		SongRogers shortestSong = null;
		double minTime = Double.MAX_VALUE;
		int i = 0;
		
		for (i = 0; i < mySize; i++)
			{
			if ((mySongs[i].getMinutes() * 60) + (mySongs[i].getSeconds()) < minTime)
				{
				minTime = (mySongs[i].getMinutes() * 60) + (mySongs[i].getSeconds());
				shortestSong = mySongs[i];
				} // if
			} // for
		
		return shortestSong;
		} // findLongest
	
	/**
	 * This method calculates the total price of the songs in the playlist
	 * @return	Returns the total price
	 */
	public double calcTotal()
		{
		double totalPrice = 0.0;
		int i = 0;
		
		for (i = 0; i < mySize; i++)
			totalPrice += mySongs[i].getPrice();
		return totalPrice;
		} // calcTotal
	
	/**
	 * This method outputs all the details of all the songs in the playlist
	 */
	public void printFullPlaylist()
		{
		int i = 0;
		for (i = 0; i < mySize; i++)
			{
			System.out.println("~~~ Song (" + (i+1) + ") ~~~");
			System.out.println(mySongs[i].toString());
			System.out.println();
			} // for
		} // printFullPlylist
	
	/**
	 * This method deletes the song in the playlist with the longest runtime
	 * @return	Returns whether the longest song was deleted or not
	 */
	public boolean deleteLongest()
		{
		SongRogers theLongest = findLongest();
		boolean found = false;
		int i = 0;
		
		while ((found == false) && (i < mySize)) 
			{
			if (mySongs[i].getName().compareToIgnoreCase(theLongest.getName()) == 0)
				{
				mySongs[i] = null;
				found = true;
				} // if
			else
				i++;
			} // while
		
		if (i != (mySongs.length - 1))
			{
			while (i < (mySongs.length - 1)) 
				{
				mySongs[i] = mySongs[i + 1];
				i++;			
				} // while
			} //if
		
		if (mySize != 0)
			mySize--;
		return found;
		} // deleteLongest
	
} // PlaylistRogers