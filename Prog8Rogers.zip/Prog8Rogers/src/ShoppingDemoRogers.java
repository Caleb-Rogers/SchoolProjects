/**
 * @author Caleb Rogers <br>
 * 
 * Prog 8 <br>
 * Due Date and Time: 04/09/20 before 12:00 a.m. <br>
 * 
 * Purpose: This program uses a keyed list class to create and modify a 
 * 			shopping list. <br>
 * 
 * Input: File name, menu choice, item name, item quantity, item price,
 * 		  and item to delete.  <br>
 * 
 * Output: Menu, items in list, searched item, number of items, total
 * 		   cost, whether list is empty, and whether list is full <br>
 * 
 * Certification of Authenticity: <br>
 * I certify that this lab is entirely my own work <br>
 */

import java.io.*;
import java.util.*;
import java.text.*;

public class ShoppingDemoRogers
{
	
	static Scanner keyboard = new Scanner(System.in);
	static DecimalFormat moneyStyle = new DecimalFormat("0.00");
	
	public static void main(String[] args) 
	{
		// Initialization
		String fileName;
		File myFile;
		Scanner input;
		int inputNumItems = 0;
		int i = 0;
		String inputName = null;
		int inputQuantity = 0;
		double inputPrice = 0.0;
		ItemRogers inputItems = new ItemRogers(inputName, inputQuantity, inputPrice);
		KeyedListRogers theList = new KeyedListRogers();
		String menuChoice;
		char menu;
		String itemName = null;
		int itemQuantity = 0;
		double itemPrice = 0.0;
		ItemRogers newItem = new ItemRogers(itemName, itemQuantity, itemPrice);
		boolean added = false;
		String deleteItem = null;
		boolean deleted = false;
		String searchItem = null;
		ItemRogers foundItem = null;
		boolean empty = false;
		boolean full = false;
		
		// Greeting
		System.out.println("Welcome, this program will allow you to create and modify a shopping list!!");
		
		// File Input
		System.out.println("\nAn input file will be required to populate your shopping list");
		System.out.print("Enter a filename: ");
		fileName = keyboard.next();
		myFile = new File(fileName);
				
		try
			{
			input = new Scanner(myFile);
			inputNumItems = input.nextInt();
			
			for(i = 0; i < inputNumItems; i++)
				{
				inputName = input.next();
				inputQuantity = input.nextInt();
				inputPrice = input.nextDouble();
						
				inputItems = new ItemRogers(inputName, inputQuantity, inputPrice);
				theList.add(inputItems);
				} // for
					
			input.close();
			} // try
		catch(FileNotFoundException ex)
			{
			System.out.println("Failed to find the file: " + myFile.getAbsolutePath());
			} // catch
		catch(InputMismatchException ex)
			{
			System.out.println("Type mismatch for the number I tried to read!");
			System.out.println(ex.getMessage());
			} // catch
		catch(NumberFormatException ex)
			{
			System.out.println("Failed to convert string text into integer value!");
			System.out.println(ex.getMessage());
			} // catch
		catch(NullPointerException ex)
			{
			System.out.println("Null pointer exception");
			System.out.println(ex.getMessage());
			} // catch
		catch(Exception ex)
			{
			System.out.println("There was an error!");
			ex.printStackTrace();
			} // catch
				
		System.out.println(theList.getSize() + " items have been added to your shopping list!");
		
		do 
			{
			// Menu
			System.out.println();
			System.out.println("{Select a choice from the following menu}");
			System.out.println("'1': Add an item to the list");
			System.out.println("'2': Delete an item from the list");
			System.out.println("'3': Print each item in the list");
			System.out.println("'4': Search for a user-specified item in the list");
			System.out.println("'5': Count the total number of items in the list");
			System.out.println("'6': Total the cost of the items in the list");
			System.out.println("'7': Determine whether the list is empty");
			System.out.println("'8': Determine whether the list is full");
			System.out.println("'9': Clear the list");
			System.out.println("'0': Quit Program");
			
			// Menu Choice
			System.out.print("Enter your menu choice: ");
			menuChoice = keyboard.next();
			menu = menuChoice.charAt(0);
			menu = Character.toUpperCase(menu);
			System.out.println();
			
			// Menu Selection
			switch (menu)
				{
				case '1': System.out.println("Want to add an item to your shopping list?");
						System.out.println("Input the following information");
						
						System.out.print("Enter the name of the item: ");
						itemName = keyboard.next();
						
						System.out.print("Enter the quantity of the item: ");
						itemQuantity = keyboard.nextInt();
						while (itemQuantity <= 0)
							{
							System.out.print("Invalid input! Enter a positive number: ");
							itemQuantity = keyboard.nextInt();
							} // while
						
						System.out.print("Enter the unit price of the item: ");
						itemPrice = keyboard.nextDouble();
						while (itemPrice < 0)
							{
							System.out.print("Invalid input! Enter a positive number: ");
							itemPrice = keyboard.nextDouble();
							} // while
						
						newItem = new ItemRogers(itemName, itemQuantity, itemPrice);
						added = theList.add(newItem);
						
						if (added == true)
							System.out.println("\nThe item " + itemName + " was added to your shopping list");
						else
							System.out.println("\nThere was an issue! The item " + itemName + " was NOT added to your shopping list");
						break;
					
				case '2': System.out.println("Want to delete an item from your shopping list?");
						System.out.print("Enter the item you want deleted: ");
						deleteItem = keyboard.next();
						
						deleted = theList.remove(deleteItem);
						
						if(deleted == true)
							System.out.println("\nThe item " + deleteItem + " was deleted from your shopping list");
						else
							System.out.println("\nThere was an issue! The item " + deleteItem + " was NOT deleted from your shopping list");
							break;
					
				case '3': System.out.println("The following represents all the items in your shopping list!");
						if (theList.getSize() == 0)
							System.out.println("There are currently no items in your shopping list!");
						else
							theList.print();
						break;
					
				case '4': System.out.println("Want to search an item in your shopping list?");
						System.out.print("Enter the name of the item you want to find: ");
						searchItem = keyboard.next();
						foundItem = theList.retrieve(searchItem);
						if(foundItem != null)
							{
							System.out.println("\nYour item was found! Here is your item");
							System.out.println(foundItem.toString());
							} // if
						else
							System.out.println("\nThere was an issue! " + searchItem + " was unable to be found");
						break;
					
				case '5': System.out.println("Want to know how many items are in your shopping list?");
						System.out.println("There are " + theList.getCount() + " items in your shopping list");
						break;
					
				case '6': System.out.println("Want to know the total cost of your shopping list?");
						System.out.println("Your total cost is currently $" + moneyStyle.format(theList.calcTotal()));
						break;
				
				case '7': System.out.println("Want to know if your shopping list is empty?");
						empty = theList.isEmpty();
						if(empty == true)
							System.out.println("There are currently NO items, your shopping list is empty");
						else
							System.out.println("Currently there are items, your shopping list is NOT empty");
						break;
						
				case '8': System.out.println("Want to know if your shopping list is full?");
						full = theList.isFull();
						if(full == true)
							System.out.println("Your shopping list appears to be full with items");
						else
							System.out.println("Your shopping list is NOT full with items");
						break;
						
				case '9': System.out.println("Want to clear your shopping list?");
						theList.clear();
						System.out.println("Cleared! There are no items left in your shopping list");
						break;
						
				case '0': System.out.println("Thanks for participating in Caleb's experimental program!");
						System.out.println("Goodbye");
						keyboard.close();
						break;
						
				default: System.out.println("Invalid input! Enter an option from the menu ");
						break;
				} // switch
			} // do
		while (menu != '0');	
	} // main
} // ShoppingDemoRogers