/**
 * 
 * @author Caleb Rogers <br>
 * 
 * This is the class definition for KeyedListRogers
 */
public class KeyedListRogers 
{
/**
* Instance variable for the array of items in the shopping list
*/
private ItemRogers[] myItems;

/**
 * Instance variable for the number of items in the shopping list
 */
private int mySize;

/**
 * This method finds the index of an item
 * @param keyValue	item needed to find index
 * @return
 */
private int findIndex(String nameOfItem)
	{
	int index = -1;
	int i = 0;
	while(i < mySize)
		{
		if(nameOfItem.compareToIgnoreCase(myItems[i].getName()) == 0) 
			index = i;
		i++;
		} // while
	return index;
	} // findIndex

	/**
	 * The default constructor for KeyedListRogers
	 */
	public KeyedListRogers()
		{
		int i = 0;
		myItems = new ItemRogers[10];
		for (i = 0; i < 10; i++)
			myItems[i] = null;
		mySize = 0;
		} // KeyedListRogers
		
	/**
	 * The getter for the shopping list's size
	 * @return mySize	The size of the shopping list
	 */
	public int getSize()
		{
		return mySize;
		} // getSize
	
	/**
	 * The setter for the shopping list's size
	 * @param newSize	the incoming size for the shopping list
	 */
	public void setSize(int newSize)
		{
		mySize = newSize;
		} // setSize
	
	/**
	 * This method clears the shopping list
	 */
	public void clear()
		{
		mySize = 0;
		} // clear
	
	/**
	 * This method adds a new item to the shopping list
	 * @param product	item to be added
	 * @return success	whether item was added or not
	 */
	public boolean add(ItemRogers product)
		{
		int addIndex = -1;
		int i = 0;
		int j = 0;
		boolean success = false;
		
		if(mySize != myItems.length)
			{
			addIndex = findIndex(product.getName());
			
			if(addIndex == -1)
				{
				while((i < mySize) && (product.getName().compareToIgnoreCase(myItems[i].getName()) > 0))
					i++;
				
				for(j = mySize-1; j >= i; j--)
					myItems[j+1] = myItems[j];
			
				myItems[i] = product;
				success = true;
				mySize++;
				} // if
			} // if
		return success;
		} // add
	
	/**
	 * removes an item from the shopping list
	 * @param keyValue	item to be removed
	 * @return success	whether item was deleted or not
	 */
	public boolean remove(String delItem)
		{
		int delIndex = -1;
		int i = 0;
		boolean success = false;
		
		delIndex = findIndex(delItem);
			
		if(delIndex != -1)
			{				
			myItems[delIndex] = null;
				
			for(i = delIndex+1; i < mySize; i++)
				myItems[i-1] = myItems[i];
			
			success = true;
			mySize--;
			} // if
		return success;
		} // remove
	
	/**
	 * This method returns a searched item
	 * @param keyValue	name of item being searched
	 * @return theItem	item that was searched
	 */
	public ItemRogers retrieve(String findItem)
		{
		int i =0;
		ItemRogers theItem = null;
		while(i < mySize)
			{
			if(findItem.compareToIgnoreCase(myItems[i].getName()) == 0)
				theItem = myItems[i];
			i++;
			} // while
		return theItem;
		} // retrieve
	
	/**
	 * This method returns whether the shopping list is empty or not
	 * @return empty   whether shopping list is empty or not
	 */
	public boolean isEmpty()
		{
		boolean empty = false;
		if(mySize == 0)
			empty = true;
		return empty;
		} // isEmpty
	
	/**
	 * This method returns whether the shopping list is full or not
	 * @return full	  whether shopping list is full or not
	 */
	public boolean isFull() // validate after clear
		{
		boolean full = false;
		if(mySize == myItems.length)
			full = true;
		return full;
		} // isFull
	
	/**
	 * This method prints the items in the shopping list
	 */
	public void print()
		{
		int i = 0;
		while(i < mySize)
			{
			System.out.println("~~~~~ " + (i+1) + " ~~~~~");
			System.out.println(myItems[i].toString());
			System.out.println();
			i++;
			} // while
		} // print
	
	/**
	 * This method counts how many items are in the shopping list
	 * @return totalCount	number of items in shopping list
	 */
	public int getCount()
		{
		int i = 0;
		int totalCount = 0;
		while(i < mySize)
			{
			totalCount += myItems[i].getQuantity();
			i++;
			} // while
		return totalCount;
		} // getCount
	
	/**
	 * This method calculates the total price of the shopping list
	 * @return totalCost	total cost of shopping list
	 */
	public double calcTotal()
		{
		int i = 0;
		double totalCost = 0.0;
		while(i < mySize)
			{
			totalCost += myItems[i].getQuantity() * myItems[i].getPrice();
			i++;
			} // while
		return totalCost;
		} // calcTotal
	
} // KeyedListRogers
