/**
 * 
 * @author Caleb Rogers <br>
 *
 * This is the class definition for ItemRogers
 */

import java.text.*;

public class ItemRogers 
{
/**
 * Instance variable for item's name
 */
private String myName;
/**
 * Instance variable for item's quantity
 */
private int myQuantity;
/**
 * Instance variable for item's price
 */
private double myPrice;

	static DecimalFormat moneyStyle = new DecimalFormat("0.00");

	/**
	 * The default constructor for ItemRogers
	 */
	public ItemRogers()
		{
		myName = "None";
		myQuantity = 0;
		myPrice = 0.0;
		} // ItemRogers
	
	/**
	 * This constructor assigns incoming variables for ItemRogers
	 * @param newName		The new name for an item
	 * @param newQuantity	The new quantity for an item
	 * @param newPrice		The new price for an item
	 */
	public ItemRogers(String newName, int newQuantity, double newPrice)
		{
		myName = newName;
		myQuantity = newQuantity;
		myPrice = newPrice;
		} // ItemRogers
	
	/**
	 * The setter for an item's name
	 * @param newName	The incoming name for an item
	 */
	public void setName(String newName)
		{
		myName = newName;
		} // setName
	
	/**
	 * The setter for an item's quantity
	 * @param newQuantity	The incoming quantity for an item
	 */
	public void setQuantity(int newQuantity)
		{
		myQuantity = newQuantity;
		} // setQuantity
	
	/**
	 * The setter for an item's price
	 * @param newPrice	The incoming price for an item
	 */
	public void setPrice(double newPrice)
		{
		myPrice = newPrice;
		} // setPrice
	
	/**
	 * The getter for an item's name
	 * @return	Returns the name of an item
	 */
	public String getName()
		{
		return myName;
		} // getName
	
	/**
	 * The getter for an item's quantity
	 * @return	Returns the quantity of an item
	 */
	public int getQuantity()
		{
		return myQuantity;
		} // getQuantity
	
	/**
	 * The getter for an item's price
	 * @return	Returns the price of an item
	 */
	public double getPrice()
		{
		return myPrice;
		} // getPrice
	
	/**
	 * This method creates a string representation of an item
	 * @return	Returns the string representation of an item
	 */
	public String toString()
		{
		String result = "Name of Item: " + myName + "\n";
		result += "Quantity of Item: " + myQuantity + "\n";
		result += "Unit Price of Item: $" + moneyStyle.format(myPrice);
		return result;
		} // toString
	
} // ItemRogers